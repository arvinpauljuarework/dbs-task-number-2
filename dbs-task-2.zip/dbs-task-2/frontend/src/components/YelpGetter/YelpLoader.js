import React from 'react';

// import './BusinessCard.css';

const yelpLoader = (props) => (
    
    <div className="row"><div className="mx-auto"><img src="https://media.giphy.com/media/jAYUbVXgESSti/giphy.gif"></img></div></div>

);

export default yelpLoader;