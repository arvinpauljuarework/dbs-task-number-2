import React from 'react';

import './BusinessCard.css';

const businessNoData = (props) => (
    
    <div className="mx-auto"><p className="no-data-label">No Data</p></div>
);

export default businessNoData;