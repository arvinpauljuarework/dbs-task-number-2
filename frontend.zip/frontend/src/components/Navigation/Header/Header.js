import React from 'react';

const header  = (props) => (
    <header>
        <nav className="navbar navbar-dark bg-dark">
            <span className="navbar-brand mb-0 h1">Business Finder</span>
        </nav>
    </header>
);

export default header;